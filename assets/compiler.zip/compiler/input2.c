#include<stdio.h>
int main{
 printf('hii  miss');/*hiiiiiii bulu  */
 }
